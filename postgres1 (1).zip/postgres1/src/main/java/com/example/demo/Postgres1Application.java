package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Postgres1Application {

	public static void main(String[] args) {
		SpringApplication.run(Postgres1Application.class, args);
	}

}
